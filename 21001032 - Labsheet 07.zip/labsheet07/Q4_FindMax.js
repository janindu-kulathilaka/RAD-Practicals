const number = [23, 45, 12, 67, 5, 89, 34, 56];
const maxNumber = Math.max(...number);

console.log(`Mximum number in the array: ${maxNumber}`);
